from django.apps import AppConfig


class AiConfig(AppConfig):
    name = 'ai'
